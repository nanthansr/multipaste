import { ClipItem, ExcludedApp, AppPreferences } from './types';

export const INITIAL_CLIPS: ClipItem[] = [
  {
    id: '1',
    type: 'code',
    content: `struct ClipItemView: View {
    let clip: ClipboardClip
    var body: some View {
        HStack(spacing: 12) {
            Image(nsImage: clip.appIcon)
                .resizable()
                .frame(width: 20, height: 20)
            VStack(alignment: .leading, spacing: 4) {
                Text(clip.title)
                    .font(.headline)
                    .foregroundColor(.white)
                Text(clip.contentSnippet)
                    .font(.footnote)
                    .foregroundColor(.gray)
            }
        }
        .padding(.vertical, 8)
    }
}`,
    title: 'Client Swift UI View',
    sourceApp: 'Xcode',
    sourceAppBundle: 'com.apple.dt.Xcode',
    timestamp: new Date(Date.now() - 3 * 60 * 1000), // 3 mins ago
    charCount: 462,
    wordCount: 52,
    byteSize: '462 B',
    codeLanguage: 'swift'
  },
  {
    id: '2',
    type: 'color',
    content: '#9f5fef',
    title: 'Brand Violet Accent',
    sourceApp: 'Figma',
    sourceAppBundle: 'com.figma.Desktop',
    timestamp: new Date(Date.now() - 17 * 60 * 1000), // 17 mins ago
    charCount: 7,
    wordCount: 1,
    byteSize: '7 B',
    colorHex: '#9f5fef'
  },
  {
    id: '3',
    type: 'link',
    content: 'https://ai.google.dev/gemini-api/docs',
    title: 'Gemini API Reference Documentation',
    sourceApp: 'Safari',
    sourceAppBundle: 'com.apple.Safari',
    timestamp: new Date(Date.now() - 42 * 60 * 1000), // 42 mins ago
    charCount: 37,
    wordCount: 1,
    byteSize: '37 B',
    previewUrl: 'https://ai.google.dev/gemini-api/docs'
  },
  {
    id: '4',
    type: 'text',
    content: 'The major key to clipboard efficiency is keeping a local-first memory index that responds instantly to keyboard combinations. Multi-format support ensures your text, links, color swatches, and image captures are always at hand.',
    title: 'Design Principles Note',
    sourceApp: 'Drafts',
    sourceAppBundle: 'com.agi.Drafts',
    timestamp: new Date(Date.now() - 90 * 60 * 1000), // 1.5 hours ago
    charCount: 221,
    wordCount: 35,
    byteSize: '221 B'
  },
  {
    id: '5',
    type: 'image',
    content: 'Interactive Applet UI Design Specs Mockup (1280x800 px)',
    title: 'Screenshot_Figma_2026.png',
    sourceApp: 'Pixelmator Pro',
    sourceAppBundle: 'com.pixelmator.pixelmatorpro',
    timestamp: new Date(Date.now() - 3 * 3600 * 1000), // 3 hours ago
    charCount: 48,
    wordCount: 5,
    byteSize: '1.4 MB',
    previewUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: '6',
    type: 'code',
    content: `// Tailwind responsive container layout
<div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
  <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
    <aside className="md:col-span-3 bg-slate-900 border border-slate-800 rounded-xl p-4">
      {/* Navigation rails */}
    </aside>
  </div>
</div>`,
    title: 'Responsive Tailwind Skeleton',
    sourceApp: 'VS Code',
    sourceAppBundle: 'com.microsoft.VSCode',
    timestamp: new Date(Date.now() - 5 * 3600 * 1000), // 5 hours ago
    charCount: 247,
    wordCount: 25,
    byteSize: '247 B',
    codeLanguage: 'html'
  },
  {
    id: '7',
    type: 'color',
    content: '#10b981',
    title: 'System Success Green',
    sourceApp: 'Figma',
    sourceAppBundle: 'com.figma.Desktop',
    timestamp: new Date(Date.now() - 8 * 3600 * 1000), // 8 hours ago
    charCount: 7,
    wordCount: 1,
    byteSize: '7 B',
    colorHex: '#10b981'
  }
];

export const EXCLUDED_APPS_DEFAULT: ExcludedApp[] = [
  { id: '1', name: 'Keychain Access', bundleIdentifier: 'com.apple.keychainaccess', isChecked: true },
  { id: '2', name: 'Bitwarden', bundleIdentifier: 'com.bitwarden.desktop', isChecked: true },
  { id: '3', name: '1Password', bundleIdentifier: 'com.1password.1password', isChecked: true },
  { id: '4', name: 'Notes (Private Only)', bundleIdentifier: 'com.apple.Notes', isChecked: false },
  { id: '5', name: 'Terminal / SSH', bundleIdentifier: 'com.apple.Terminal', isChecked: false }
];

export const PREFERENCES_DEFAULT: AppPreferences = {
  launchAtLogin: true,
  collectInFIFO: false,
  soundOnCopy: true,
  universalSync: true,
  excludeSensitiveData: true,
  historyLimit: 500,
  globalHotkey: '⌥ ⌘ V',
  excludedApps: EXCLUDED_APPS_DEFAULT,
  telemetryEnabled: false
};
