import React, { useState, useEffect } from 'react';
import { 
  Eclipse, 
  Plus, 
  Sun, 
  Moon, 
  Sparkles,
  BookOpen,
  Layers,
  Compass,
  Settings,
  Award
} from 'lucide-react';

// Modules imports
import LandingPage from './components/LandingPage';
import MenuBarPopover from './components/MenuBarPopover';
import ActiveDashboard from './components/ActiveDashboard';
import SettingsPanel from './components/SettingsPanel';
import LicenseActivation from './components/LicenseActivation';

// Mock helpers
import { INITIAL_CLIPS, PREFERENCES_DEFAULT } from './data';
import { ClipItem, AppPreferences } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('landing');
  const [clips, setClips] = useState<ClipItem[]>(INITIAL_CLIPS);
  const [preferences, setPreferences] = useState<AppPreferences>(PREFERENCES_DEFAULT);
  const [isDark, setIsDark] = useState<boolean>(true);

  // Synchronize base HTML and document body styles for pristine themes
  useEffect(() => {
    if (isDark) {
      document.body.style.background = `radial-gradient(at 0% 0%, rgba(30,27,75,0.4) 0%, transparent 60%), radial-gradient(at 100% 100%, rgba(15,23,42,0.9) 0%, #07090f 100%)`;
      document.body.style.backgroundColor = '#07090e';
      document.body.style.color = '#f1f5f9';
      document.documentElement.classList.add('dark');
    } else {
      document.body.style.background = `radial-gradient(at 0% 0%, rgba(59,130,246,0.05) 0%, transparent 50%), radial-gradient(at 100% 100%, rgba(99,102,241,0.03) 0%, #f8fafc 100%)`;
      document.body.style.backgroundColor = '#f8fafc';
      document.body.style.color = '#0f172a';
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Handler to restore defaults
  const handleRestoreDefaults = () => {
    setPreferences(PREFERENCES_DEFAULT);
  };

  // Handler to modify preferences easily
  const handleUpdatePreferences = (updated: Partial<AppPreferences>) => {
    setPreferences(prev => ({ ...prev, ...updated }));
  };

  // Clear clips standard action
  const handleClearClips = () => {
    setClips([]);
  };

  // Append new mock clipboard item manually
  const handleAddMockClip = () => {
    const mockOptions = [
      {
        type: 'code' as const,
        content: `func fetchDeviceUUID() -> String {\n    return UIDevice.current.identifierForVendor?.uuidString ?? ""\n}`,
        title: 'Device ID Extractor (Swift)',
        sourceApp: 'Xcode',
        sourceAppBundle: 'com.apple.dt.Xcode',
      },
      {
        type: 'color' as const,
        content: '#10b981',
        title: 'Emerald Success Green',
        sourceApp: 'Figma',
        sourceAppBundle: 'com.figma.Desktop',
        colorHex: '#10b981'
      },
      {
        type: 'link' as const,
        content: 'https://github.com/apple/swift-evolution',
        title: 'Swift Evolution Repository',
        sourceApp: 'Safari',
        sourceAppBundle: 'com.apple.Safari',
      },
      {
        type: 'text' as const,
        content: 'A local clipboard buffer should store elements color-coded, searchable in memory, and totally private from external network requests.',
        title: 'Multipaste Security Spec',
        sourceApp: 'Notes',
        sourceAppBundle: 'com.apple.Notes',
      }
    ];

    const pick = mockOptions[Math.floor(Math.random() * mockOptions.length)];
    const newItem: ClipItem = {
      id: String(Date.now()),
      ...pick,
      timestamp: new Date(),
      charCount: pick.content.length,
      wordCount: pick.content.split(' ').length,
      byteSize: `${pick.content.length} B`
    };
    
    setClips(prev => [newItem, ...prev]);
  };

  const handleSuccessActivate = () => {
    setActiveTab('dashboard');
  };

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'landing':
        return (
          <LandingPage 
            onNavigateToSandbox={(view) => setActiveTab(view)}
            clips={clips}
            onAddClip={(clip) => setClips(prev => [clip, ...prev])}
            isDark={isDark}
          />
        );
      case 'popover':
        return (
          <MenuBarPopover 
            clips={clips}
            onAddClip={(clip) => setClips(prev => [clip, ...prev])}
            onClearClips={handleClearClips}
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
            isDark={isDark}
          />
        );
      case 'dashboard':
        return (
          <ActiveDashboard 
            clips={clips}
            onAddClip={(clip) => setClips(prev => [clip, ...prev])}
            isDark={isDark}
          />
        );
      case 'settings':
        return (
          <SettingsPanel 
            preferences={preferences}
            onUpdatePreferences={handleUpdatePreferences}
            onRestoreDefaults={handleRestoreDefaults}
            isDark={isDark}
          />
        );
      case 'activator':
        return (
          <LicenseActivation 
            onSuccessActivate={handleSuccessActivate}
            isDark={isDark}
          />
        );
      default:
        return <div className="p-8 text-center font-mono">Select workspace tab to start.</div>;
    }
  };

  return (
    <div className={`min-h-screen text-slate-100 flex flex-col font-sans relative selection:bg-blue-500/30 transition-colors duration-300`}>
      
      {/* Visual Workspace Bar Header (Elegant, Simple, Product-centered) */}
      <header className={`px-6 py-4 flex flex-col md:flex-row items-center justify-between border-b shrink-0 z-30 transition-all duration-300 ${isDark ? 'bg-black/35 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-sm'}`}>
        <div className="flex items-center gap-3">
          <div className="w-8.5 h-8.5 rounded-xl bg-gradient-to-tr from-blue-500 via-indigo-500 to-violet-600 flex items-center justify-center font-bold text-white shadow-md shadow-blue-500/10 shrink-0">
            <Eclipse className="w-4.5 h-4.5 text-white animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display font-bold text-base tracking-tight select-none">Multipaste</h1>
              <span className={`text-[10px] font-bold border px-2 py-0.5 rounded-full uppercase font-mono tracking-wider ${isDark ? 'bg-blue-950/40 border-blue-900/40 text-blue-300' : 'bg-blue-50 border-blue-100 text-blue-600'}`}>
                v1.4 macOS
              </span>
            </div>
            <p className={`text-[11px] font-medium leading-tight mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Continuous private clipboard supervisor for macOS & iOS
            </p>
          </div>
        </div>

        {/* Unified Application Navigation Menu */}
        <div className="flex flex-wrap items-center gap-4 mt-3 md:mt-0">
          <div className={`flex items-center gap-1 p-1 rounded-xl border ${isDark ? 'bg-black/35 border-white/5' : 'bg-slate-100 border-slate-200'}`}>
            {[
              { id: 'landing', label: 'Product Home', icon: <BookOpen className="w-3.5 h-3.5" /> },
              { id: 'popover', label: 'Status Bar App', icon: <Compass className="w-3.5 h-3.5" /> },
              { id: 'dashboard', label: 'Clipboard History', icon: <Layers className="w-3.5 h-3.5" /> },
              { id: 'settings', label: 'Bundle Exclusions', icon: <Settings className="w-3.5 h-3.5" /> },
              { id: 'activator', label: 'Go Pro Licence', icon: <Award className="w-3.5 h-3.5" /> }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${activeTab === tab.id ? (isDark ? 'bg-blue-600 text-white shadow-sm shadow-blue-900/20' : 'bg-white text-blue-600 border border-slate-200/80 shadow-xs') : (isDark ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:text-slate-900')}`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Mock Clip generator */}
            <button 
              onClick={handleAddMockClip}
              className={`flex items-center gap-1.5 px-3 py-1.5 border rounded-lg text-xs font-semibold cursor-pointer active:scale-95 transition-all ${isDark ? 'bg-white/10 hover:bg-white/15 border-white/10 text-white' : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800'}`}
              title="Copy a simulated item to verify clipboard capture flow instantly"
            >
              <Plus className="w-3.5 h-3.5 text-blue-500" />
              <span>Copy Simulated Item</span>
            </button>

            {/* Light/Dark Toggle Switch */}
            <button
              onClick={() => setIsDark(!isDark)}
              className={`p-2 rounded-xl border cursor-pointer active:scale-90 transition-all ${isDark ? 'bg-white/5 border-white/10 text-amber-300 hover:bg-white/10' : 'bg-slate-100 border-slate-200 text-indigo-600 hover:bg-slate-200'}`}
              title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
            >
              {isDark ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Center Adaptive Workstation View */}
      <div className="flex-1 flex flex-col min-h-0 relative">
        <main className="flex-1 overflow-y-auto relative min-h-[500px]">
          {renderActiveComponent()}
        </main>
      </div>

      {/* Discrete Elegant Footer */}
      <footer className={`border-t px-6 py-3 shrink-0 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono select-none transition-all duration-300 ${isDark ? 'bg-black/15 border-white/5 text-slate-500' : 'bg-slate-50 border-slate-200 text-slate-500'}`}>
        <span className="flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${isDark ? 'bg-blue-500' : 'bg-blue-600'} animate-pulse`}></span>
          <span>Multipaste Clipboard Buffer Simulator Connected</span>
        </span>
        <span className="mt-1 sm:mt-0 font-medium">Fully runs local-first on client device</span>
      </footer>

    </div>
  );
}
