export type ItemType = 'text' | 'code' | 'color' | 'image' | 'link';

export interface ClipItem {
  id: string;
  type: ItemType;
  content: string;
  title?: string;
  sourceApp: string;
  sourceAppBundle: string;
  timestamp: Date | string;
  charCount?: number;
  wordCount?: number;
  byteSize: string;
  previewUrl?: string; // For images or link tags
  codeLanguage?: string; // For code blocks
  colorHex?: string; // For color elements
}

export interface ExcludedApp {
  id: string;
  name: string;
  bundleIdentifier: string;
  isChecked: boolean;
}

export interface AppPreferences {
  launchAtLogin: boolean;
  collectInFIFO: boolean;
  soundOnCopy: boolean;
  universalSync: boolean;
  excludeSensitiveData: boolean;
  historyLimit: number;
  globalHotkey: string;
  excludedApps: ExcludedApp[];
  telemetryEnabled: boolean;
}

export type DesignTheme = 'obsidian' | 'lumina' | 'cosmic' | 'glass';

export interface ActiveThemeConfig {
  id: DesignTheme;
  name: string;
  bgColor: string;
  cardBg: string;
  textColor: string;
  accentColor: string;
  accentHover: string;
  borderColor: string;
  shadow: string;
}

export const THEME_CONFIGS: Record<DesignTheme, ActiveThemeConfig> = {
  glass: {
    id: 'glass',
    name: 'Frosted Glass (Aero)',
    bgColor: 'bg-transparent',
    cardBg: 'glass-card',
    textColor: 'text-white',
    accentColor: 'text-[#3b82f6] bg-[#3b82f6]/10 border-[#3b82f6]/25',
    accentHover: 'hover:bg-[#3b82f6]/20',
    borderColor: 'border-white/10',
    shadow: 'shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5)]',
  },
  obsidian: {
    id: 'obsidian',
    name: 'Obsidian Stealth (Pro)',
    bgColor: 'bg-[#090b10]',
    cardBg: 'bg-[#121620]/90 backdrop-blur-md',
    textColor: 'text-slate-100',
    accentColor: 'text-[#9d4edd] bg-[#9d4edd]/10 border-[#9d4edd]/20',
    accentHover: 'hover:bg-[#9d4edd]/20',
    borderColor: 'border-slate-800/80',
    shadow: 'shadow-[0_8px_30px_rgb(0,0,0,0.8)]',
  },
  lumina: {
    id: 'lumina',
    name: 'Lumina Precision (Light)',
    bgColor: 'bg-[#f8fafc]',
    cardBg: 'bg-white/95 border border-slate-200/80 shadow-md',
    textColor: 'text-slate-800',
    accentColor: 'text-[#2563eb] bg-[#2563eb]/10 border-[#2563eb]/20',
    accentHover: 'hover:bg-[#2563eb]/20',
    borderColor: 'border-slate-200',
    shadow: 'shadow-[0_4px_20px_rgba(148,163,184,0.15)]',
  },
  cosmic: {
    id: 'cosmic',
    name: 'Cosmic Royal (Vibrant)',
    bgColor: 'bg-[#0a051b]',
    cardBg: 'bg-[#150a2e]/60 backdrop-blur-xl border border-indigo-500/25',
    textColor: 'text-purple-100',
    accentColor: 'text-pink-400 bg-pink-500/10 border-pink-500/25',
    accentHover: 'hover:bg-pink-500/20',
    borderColor: 'border-indigo-500/20',
    shadow: 'shadow-[0_8px_32px_rgba(236,72,153,0.15)]',
  },
};
