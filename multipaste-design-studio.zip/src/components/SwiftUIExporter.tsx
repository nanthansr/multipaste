import React, { useState } from 'react';
import { Copy, Check, FileCode, Sparkles } from 'lucide-react';

interface ExporterProps {
  theme: 'obsidian' | 'lumina' | 'cosmic';
}

const SWIFTUI_SAMPLES = {
  clipRow: `// High-Fidelity SwiftUI clip list row mapping exactly to Obsidian Stealth details
import SwiftUI

struct MultipasteClipRow: View {
    let title: String
    let appSource: String
    let appBundle: String
    let timeAgo: String
    let type: String
    let content: String
    let index: Int
    @State private var isHovered = false
    
    var body: some View {
        HStack(spacing: 12) {
            // Index & indicator
            Text("\\(index)")
                .font(.system(.caption2, design: .monospaced))
                .foregroundColor(isHovered ? .purple : .gray.opacity(0.8))
                .frame(width: 14, alignment: .trailing)
            
            // App Icon Placeholder / Visual
            ZStack {
                RoundedRectangle(cornerRadius: 6, style: .continuous)
                    .fill(Color(red: 0.1, green: 0.12, blue: 0.18))
                    .frame(width: 24, height: 24)
                
                Image(systemName: systemIcon(for: appSource))
                    .font(.system(size: 11))
                    .foregroundColor(.white)
            }
            
            // Text values
            VStack(alignment: .leading, spacing: 2) {
                HStack {
                    Text(title.isEmpty ? contentSnippet : title)
                        .font(.system(.body, size: 13, weight: .medium))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Spacer()
                    Text(timeAgo)
                        .font(.system(size: 11))
                        .foregroundColor(.gray)
                }
                
                Text(contentSnippet)
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.gray.opacity(0.8))
                    .lineLimit(1)
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .fill(isHovered ? Color.white.opacity(0.04) : Color.clear)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(isHovered ? Color.purple.opacity(0.2) : Color.clear, lineWidth: 1)
        )
        .onHover { hover in
            withAnimation(.spring(response: 0.2, dampingFraction: 0.75)) {
                isHovered = hover
            }
        }
    }
    
    private var contentSnippet: String {
        let trimmed = content.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.count > 50 ? String(trimmed.prefix(47)) + "..." : trimmed
    }
    
    private func systemIcon(for src: String) -> String {
        switch src.lowercased() {
        case "xcode": return "applescript"
        case "figma": return "triangle"
        case "safari": return "safari"
        case "drafts": return "square.and.pencil"
        case "vs code", "vscode": return "chevron.left.forwardslash.chevron.right"
        default: return "clipboard"
        }
    }
}`,

  menuBar: `// macOS Custom Popover Window setup for Multipaste
import Cocoa
import SwiftUI

class AppDelegate: NSObject, NSApplicationDelegate {
    var statusItem: NSStatusItem!
    var popover: NSPopover!
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Create popovers
        let contentView = MultipastePopoverView()
        
        let popover = NSPopover()
        popover.contentSize = NSSize(width: 360, height: 480)
        popover.behavior = .transient
        popover.contentViewController = NSHostingController(rootView: contentView)
        self.popover = popover
        
        // Spawn status item item
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        if let button = statusItem.button {
            button.image = NSImage(systemSymbolName: "clipboard.fill", accessibilityDescription: "Multipaste")
            button.action = #selector(togglePopover(_:))
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }
    }
    
    @objc func togglePopover(_ sender: AnyObject?) {
        if let button = statusItem.button {
            if popover.isShown {
                popover.performClose(sender)
            } else {
                popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
                popover.contentViewController?.view.window?.becomeKey()
            }
        }
    }
}`,
  
  settings: `// Lumina Precision Settings Screen Struct including exclude bindings
import SwiftUI

struct ExcludedApp: Identifiable {
    let id = UUID()
    let name: String
    let bundleIdentifier: String
    var isEnabled: Bool
}

struct MultipasteSettingsView: View {
    @State private var launchAtLogin = true
    @State private var collectFIFO = false
    @State private var soundOnCopy = true
    @State private var historyLimit: Double = 500
    @State private var hotkeyString = "⌥ ⌘ V"
    @State private var excludedApps: [ExcludedApp] = [
        ExcludedApp(name: "Keychain Access", bundleIdentifier: "com.apple.keychainaccess", isEnabled: true),
        ExcludedApp(name: "Bitwarden", bundleIdentifier: "com.bitwarden.desktop", isEnabled: true),
        ExcludedApp(name: "1Password", bundleIdentifier: "com.1password.1password", isEnabled: true)
    ]

    var body: some View {
        TabView {
            // General Panel
            Form {
                Section(header: Text("Core Engine").font(.headline)) {
                    Toggle("Launch Multipaste at login", isOn: $launchAtLogin)
                    Toggle("Play audio on clips captured", isOn: $soundOnCopy)
                    Toggle("Enable FIFO queue clipboard pasting", isOn: $collectFIFO)
                }
                
                Section(header: Text("History Limits").font(.headline)) {
                    VStack(alignment: .leading, spacing: 4) {
                        Slider(value: $historyLimit, in: 50...5000, step: 50) {
                            Text("Clips Limit")
                        }
                        Text("\\(Int(historyLimit)) clips standard buffer size")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                Section(header: Text("Global Hotkeys").font(.headline)) {
                    HStack {
                        Text("Toggle HUD Window")
                        Spacer()
                        Button(action: {}) {
                            Text(hotkeyString).bold()
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(Color.purple)
                    }
                }
            }
            .tabItem {
                Label("General", systemImage: "gearshape")
            }
            .padding()
            
            // Exclusions Panel
            VStack(alignment: .leading, spacing: 12) {
                Text("Manage Exclusions")
                    .font(.title2).bold()
                Text("Avoid capturing passwords, personal tokens, or credit cards from specified apps.")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                List {
                    ForEach($excludedApps) { $app in
                        HStack {
                            VStack(alignment: .leading) {
                                Text(app.name).font(.body)
                                Text(app.bundleIdentifier).font(.caption).foregroundColor(.secondary)
                            }
                            Spacer()
                            Toggle("", isOn: $app.isEnabled).toggleStyle(.checkbox)
                        }
                    }
                }
            }
            .tabItem {
                Label("Security & Blocklist", systemImage: "shield.fill")
            }
            .padding()
        }
        .frame(width: 550, height: 400)
    }
}`
};

export default function SwiftUIExporter({ theme }: ExporterProps) {
  const [copied, setCopied] = useState<string | null>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'clipRow' | 'menuBar' | 'settings'>('clipRow');

  const handleCopy = (code: string, tabName: string) => {
    navigator.clipboard.writeText(code);
    setCopied(tabName);
    setTimeout(() => setCopied(null), 2000);
  };

  const themesDict = {
    glass: { bg: 'transparent', card: 'rgba(255,255,255,0.05)', border: 'rgba(255,255,255,0.1)', accent: '#3b82f6' },
    obsidian: { bg: '#090b10', card: '#121620', border: 'rgba(148,163,184,0.1)', accent: '#9d4edd' },
    lumina: { bg: '#f8fafc', card: '#ffffff', border: 'rgba(226,232,240,1.0)', accent: '#2563eb' },
    cosmic: { bg: '#0a051b', card: '#150a2e', border: 'rgba(236,72,153,0.25)', accent: '#ec4899' },
  };

  const currentThemeHexes = themesDict[theme] || themesDict.glass;

  return (
    <div id="swiftui-exporter" className="bg-[#10141f]/90 border border-slate-800 rounded-xl overflow-hidden shadow-2xl h-full flex flex-col font-sans">
      <div className="p-4 border-b border-slate-800 bg-[#0d1019] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileCode className="w-5 h-5 text-purple-400" />
          <div>
            <h3 className="font-semibold text-slate-200 text-sm">SwiftUI Code Exporter</h3>
            <p className="text-xs text-slate-400">Generate native macOS codebase structures</p>
          </div>
        </div>
        <div className="flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
          <Sparkles className="w-3 h-3 text-amber-400 animate-pulse" />
          <span className="text-[10px] font-mono font-medium text-amber-300">Claude Code Ready</span>
        </div>
      </div>

      <div className="p-4 bg-slate-950/40 border-b border-slate-800/60 grid grid-cols-4 gap-2 text-center text-xs">
        <div>
          <span className="block text-[10px] text-slate-400 font-medium uppercase tracking-wider mb-0.5">Active Accent</span>
          <span className="font-mono text-pink-400 text-[11px] block">{currentThemeHexes.accent}</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400 font-medium uppercase tracking-wider mb-0.5">Canvas Frame</span>
          <span className="font-mono text-slate-300 text-[11px] block">{currentThemeHexes.bg}</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400 font-medium uppercase tracking-wider mb-0.5">Glass Box</span>
          <span className="font-mono text-slate-300 text-[11px] block">CornerRadius: 12</span>
        </div>
        <div>
          <span className="block text-[10px] text-slate-400 font-medium uppercase tracking-wider mb-0.5">Font Pairing</span>
          <span className="font-mono text-purple-300 text-[11px] block">SF Monospaced</span>
        </div>
      </div>

      <div className="flex bg-[#0d1019] border-b border-slate-800/80 text-xs">
        <button
          onClick={() => setActiveCodeTab('clipRow')}
          className={`flex-1 py-2 px-3 font-medium transition-all ${
            activeCodeTab === 'clipRow' 
              ? 'text-purple-400 border-b-2 border-purple-500 bg-slate-900/30' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Clipboard Row
        </button>
        <button
          onClick={() => setActiveCodeTab('menuBar')}
          className={`flex-1 py-2 px-3 font-medium transition-all ${
            activeCodeTab === 'menuBar' 
              ? 'text-purple-400 border-b-2 border-purple-500 bg-slate-900/30' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Menu Bar Popover
        </button>
        <button
          onClick={() => setActiveCodeTab('settings')}
          className={`flex-1 py-2 px-3 font-medium transition-all ${
            activeCodeTab === 'settings' 
              ? 'text-purple-400 border-b-2 border-purple-500 bg-slate-900/30' 
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          macOS Settings
        </button>
      </div>

      <div className="flex-1 overflow-auto bg-slate-950 p-4 font-mono text-xs select-text relative leading-relaxed">
        <button
          onClick={() => handleCopy(SWIFTUI_SAMPLES[activeCodeTab], activeCodeTab)}
          className="absolute right-4 top-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 px-2.5 py-1.5 rounded-md flex items-center gap-1.5 transition-all text-xs cursor-pointer active:scale-95"
        >
          {copied === activeCodeTab ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>Copy for Claude Code</span>
            </>
          )}
        </button>

        <pre className="text-emerald-400/90 max-w-full overflow-x-auto whitespace-pre pr-12">
          {SWIFTUI_SAMPLES[activeCodeTab]}
        </pre>
      </div>

      <div className="p-3.5 bg-slate-900 border-t border-slate-800 text-xs text-slate-400 leading-relaxed font-sans flex items-start gap-2.5">
        <div className="bg-purple-950 text-purple-400 p-1.5 rounded-md">💡</div>
        <p>
          <strong>Synergy workflow:</strong> Copy this code and prompt **Claude Code** locally: 
          <span className="block mt-1 font-mono text-slate-300 text-[11px] bg-slate-950 p-1.5 rounded border border-slate-800">
            "Implement high-fidelity SwiftUI components inside our AppKit AppDelegate following the design structures from this code block."
          </span>
        </p>
      </div>
    </div>
  );
}
