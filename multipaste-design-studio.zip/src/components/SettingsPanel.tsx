import React, { useState } from 'react';
import { Settings, Shield, Ban, Compass, Volume2, Save, Sparkles, Check, Info, Command, AppWindow } from 'lucide-react';
import { AppPreferences, ExcludedApp } from '../types';

interface SettingsPanelProps {
  preferences: AppPreferences;
  onUpdatePreferences: (pref: Partial<AppPreferences>) => void;
  onRestoreDefaults: () => void;
  isDark: boolean;
}

export default function SettingsPanel({
  preferences,
  onUpdatePreferences,
  onRestoreDefaults,
  isDark
}: SettingsPanelProps) {
  const [activeTab, setActiveTab] = useState<'general' | 'exclusions' | 'shortcuts'>('general');
  const [showSavedFeedback, setShowSavedFeedback] = useState(false);

  // Excluded apps handler toggle
  const handleToggleApp = (appId: string) => {
    const updatedApps = preferences.excludedApps.map(app => 
      app.id === appId ? { ...app, isChecked: !app.isChecked } : app
    );
    onUpdatePreferences({ excludedApps: updatedApps });
    triggerSaveFeedback();
  };

  const triggerSaveFeedback = () => {
    setShowSavedFeedback(true);
    setTimeout(() => setShowSavedFeedback(false), 1200);
  };

  return (
    <div id="settings-panel-sandbox" className="p-4 sm:p-6 min-h-screen flex flex-col justify-start transition-colors duration-300 font-sans">
      
      {/* Title description */}
      <div className={`max-w-4xl w-full mx-auto mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-4 transition-all duration-300 ${isDark ? 'border-white/10' : 'border-slate-200'}`}>
        <div>
          <span className={`text-[10px] font-mono font-bold uppercase tracking-wider ${isDark ? 'text-indigo-400' : 'text-indigo-650'}`}>
            System Preferences Simulator
          </span>
          <h2 className={`text-base font-bold mt-0.5 ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Multipaste Application Settings
          </h2>
          <p className={`text-[11px] leading-tight mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-550'}`}>
            Configure clipboard limitations, auto-launch triggers, and security exclusions from origin applications.
          </p>
        </div>

        <button 
          onClick={onRestoreDefaults}
          className={`text-xs font-semibold self-start sm:self-center border px-3 py-1.5 rounded-lg transition-all cursor-pointer active:scale-95 ${isDark ? 'text-slate-300 border-white/10 hover:bg-white/5 bg-black/25' : 'text-slate-700 border-slate-200 hover:bg-slate-100 bg-white shadow-3xs'}`}
        >
          Restore Factory Defaults
        </button>
      </div>

      <div className={`max-w-4xl w-full mx-auto border rounded-xl shadow-lg overflow-hidden min-h-[460px] flex flex-col md:flex-row relative transition-colors duration-300 ${isDark ? 'bg-slate-900/35 border-white/10' : 'bg-white border-slate-200'}`}>
        
        {/* Save indicator float */}
        {showSavedFeedback && (
          <div className="absolute top-4 right-4 bg-emerald-900 border border-emerald-550 text-emerald-300 font-mono text-[9px] font-bold py-1 px-3 rounded-full flex items-center gap-1.5 z-40 animate-bounce">
            <Check className="w-3 h-3 text-emerald-350" />
            <span>Settings Saved Locally</span>
          </div>
        )}

        {/* Modal Left Sidebar Tab Selector */}
        <div className={`w-full md:w-56 p-4 border-r shrink-0 space-y-1 transition-all duration-300 ${isDark ? 'bg-black/25 border-white/5' : 'bg-slate-50 border-slate-150'}`}>
          <div className={`flex items-center gap-2 px-2.5 pb-4 border-b mb-3 ${isDark ? 'border-white/5' : 'border-slate-150'}`}>
            <Settings className={`w-4 h-4 ${isDark ? 'text-indigo-450' : 'text-indigo-600'}`} />
            <span className={`text-[10px] font-bold uppercase tracking-wider ${isDark ? 'text-slate-200' : 'text-slate-700'}`}>
              Multipaste Prefs
            </span>
          </div>

          {[
            { id: 'general', label: 'General Parameters', icon: <Compass className="w-4 h-4" /> },
            { id: 'exclusions', label: 'Security Exclusion Apps', icon: <Shield className="w-4 h-4" /> },
            { id: 'shortcuts', label: 'Shortcuts & Keybinds', icon: <Command className="w-4 h-4" /> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold tracking-wide text-left transition-all cursor-pointer ${activeTab === tab.id ? 'bg-blue-600 text-white shadow-xs' : (isDark ? 'text-slate-400 hover:text-slate-200 hover:bg-white/5' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100')}`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Modal Right Main Container */}
        <div className={`flex-1 p-6 text-left overflow-y-auto max-h-[460px] ${isDark ? 'bg-black/10' : 'bg-white'}`}>
          
          {/* Panel 1: General Parameters */}
          {activeTab === 'general' && (
            <div className="space-y-6">
              <h3 className={`font-bold text-xs uppercase tracking-wider border-b pb-2 ${isDark ? 'border-white/5 text-slate-200' : 'border-slate-150 text-slate-800'}`}>
                General application behaviors
              </h3>
              
              <div className="space-y-3">
                {/* Launch at Login */}
                <label className="flex items-center gap-3 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={preferences.launchAtLogin}
                    onChange={(e) => {
                      onUpdatePreferences({ launchAtLogin: e.target.checked });
                      triggerSaveFeedback();
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 bg-slate-950/20"
                  />
                  <div className="min-w-0">
                    <span className={`text-xs font-bold block ${isDark ? 'text-slate-200 group-hover:text-slate-100' : 'text-slate-800'}`}>
                      Automatic Launch At Login
                    </span>
                    <span className="text-[10px] text-slate-500 block leading-tight">
                      Start Multipaste helper on status bar automatically when you launch macOS.
                    </span>
                  </div>
                </label>

                {/* Sound FX copying */}
                <label className="flex items-center gap-3 cursor-pointer group pt-1">
                  <input 
                    type="checkbox" 
                    checked={preferences.soundOnCopy}
                    onChange={(e) => {
                      onUpdatePreferences({ soundOnCopy: e.target.checked });
                      triggerSaveFeedback();
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 bg-slate-950/20"
                  />
                  <div className="min-w-0">
                    <span className={`text-xs font-bold block ${isDark ? 'text-slate-200 group-hover:text-slate-100' : 'text-slate-800'}`}>
                      Play System Click sounds
                    </span>
                    <span className="text-[10px] text-slate-500 block leading-tight">
                      Triggers a subtle status click noise when a new item is captured.
                    </span>
                  </div>
                </label>

                {/* Secure telemetry */}
                <label className="flex items-center gap-3 cursor-pointer group pt-1">
                  <input 
                    type="checkbox" 
                    checked={preferences.telemetryEnabled}
                    onChange={(e) => {
                      onUpdatePreferences({ telemetryEnabled: e.target.checked });
                      triggerSaveFeedback();
                    }}
                    className="rounded text-blue-600 focus:ring-blue-500 bg-slate-950/20"
                  />
                  <div className="min-w-0">
                    <span className={`text-xs font-bold block ${isDark ? 'text-slate-200 group-hover:text-slate-100' : 'text-slate-800'}`}>
                      Send Anonymous Diagnostics
                    </span>
                    <span className="text-[10px] text-slate-500 block leading-tight">
                      Provides performance metrics locally to improve memory optimization speeds.
                    </span>
                  </div>
                </label>
              </div>

              {/* Slider limit */}
              <div className={`border-t pt-4 space-y-2.5 ${isDark ? 'border-white/5' : 'border-slate-150'}`}>
                <div className="flex justify-between items-center">
                  <span className={`text-xs font-bold ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>History retention capacity</span>
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${isDark ? 'bg-blue-950 text-blue-300 border-blue-900/40' : 'bg-blue-50 text-blue-600 border-blue-100'}`}>
                    {preferences.historyLimit} items
                  </span>
                </div>
                <input 
                  type="range" 
                  min={50} 
                  max={2000} 
                  step={50}
                  value={preferences.historyLimit}
                  onChange={(e) => {
                    onUpdatePreferences({ historyLimit: Number(e.target.value) });
                    triggerSaveFeedback();
                  }}
                  className="w-full h-1 bg-slate-200/80 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
                <span className="text-[10px] text-slate-500 block leading-tight">
                  Once your clipboard buffer is full, older clippings are automatically discarded to release physical system memory.
                </span>
              </div>
            </div>
          )}

          {/* Panel 2: Secure Application Exclusions Blocklist */}
          {activeTab === 'exclusions' && (
            <div className="space-y-4">
              <div className={`border-b pb-3 ${isDark ? 'border-white/5' : 'border-slate-150'}`}>
                <h3 className={`font-bold text-xs uppercase tracking-wider ${isDark ? 'text-slate-250' : 'text-slate-850'}`}>
                  Security Exclusions List
                </h3>
                <p className="text-[10px] text-slate-550 mt-0.5">
                  Prevent Multipaste from capturing keystrokes, secure passwords, and credit cards from specified application bundles.
                </p>
              </div>

              <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                {preferences.excludedApps.map(app => (
                  <div 
                    key={app.id}
                    onClick={() => handleToggleApp(app.id)}
                    className={`p-2.5 rounded-lg border flex items-center justify-between gap-3 cursor-pointer transition-all ${isDark ? 'bg-white/5 border-white/5 hover:bg-white/10' : 'bg-slate-50 border-slate-150 hover:bg-slate-100 hover:border-slate-200 shadow-3xs'}`}
                  >
                    <div>
                      <span className={`text-xs block font-bold ${app.isChecked ? (isDark ? 'text-slate-205' : 'text-slate-800') : 'text-slate-400 line-through'}`}>
                        {app.name}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono tracking-tight font-medium">
                        {app.bundleIdentifier}
                      </span>
                    </div>

                    <input 
                      type="checkbox" 
                      checked={app.isChecked}
                      onChange={() => {}} // controlled by parent div click
                      className="rounded text-blue-600 focus:ring-blue-500 mr-1"
                    />
                  </div>
                ))}
              </div>

              <div className={`p-3 border text-[10px] rounded-lg leading-relaxed flex items-start gap-2.5 ${isDark ? 'bg-red-950/20 border-red-900/20 text-red-300' : 'bg-red-50 border-red-100 text-red-700'}`}>
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-red-550" />
                <p>
                  <strong>Security Best Practice:</strong> Keep 1Password, Bitwarden, and Apple Keychain Access exclusions active so temporary sensitive password coordinates never cache locally on drive storage.
                </p>
              </div>
            </div>
          )}

          {/* Panel 3: Shortcuts Controls */}
          {activeTab === 'shortcuts' && (
            <div className="space-y-5">
              <div className={`border-b pb-3 ${isDark ? 'border-white/5' : 'border-slate-150'}`}>
                <h3 className={`font-bold text-xs uppercase tracking-wider ${isDark ? 'text-slate-250' : 'text-slate-850'}`}>
                  Shortcuts & Keybinds Modifier
                </h3>
                <p className="text-[10px] text-slate-550 mt-0.5">
                  Configure keyboard commands to evoke HUD overlay widget and history view stream instantly in an active field.
                </p>
              </div>

              <div className="space-y-4">
                <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition-all duration-300 ${isDark ? 'bg-slate-900/40 border-white/5' : 'bg-slate-50 border-slate-150'}`}>
                  <div>
                    <strong className={`text-xs block ${isDark ? 'text-white' : 'text-slate-800'}`}>Global HUD key modifier</strong>
                    <span className="text-[10.5px] text-slate-500 block">Bring up floating paste widget universally.</span>
                  </div>
                  
                  <div className={`px-3 py-1.5 rounded-lg border font-mono font-bold text-xs select-none ${isDark ? 'bg-black/40 border-indigo-900/40 text-indigo-300' : 'bg-white border-slate-200 text-indigo-600 shadow-2xs'}`}>
                    ⌥ ⌘ V
                  </div>
                </div>

                <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition-all duration-300 ${isDark ? 'bg-slate-900/40 border-white/5' : 'bg-slate-50 border-slate-150'}`}>
                  <div>
                    <strong className={`text-xs block ${isDark ? 'text-white' : 'text-slate-800'}`}>Paste Selected Item</strong>
                    <span className="text-[10.5px] text-slate-500 block">Fast-paste any row from status bar.</span>
                  </div>
                  
                  <div className={`px-3 py-1.5 rounded-lg border font-mono font-bold text-xs select-none ${isDark ? 'bg-black/40 border-indigo-900/40 text-indigo-300' : 'bg-white border-slate-200 text-indigo-600 shadow-2xs'}`}>
                    ⌥ 1 ... ⌥ 9
                  </div>
                </div>

                <div className={`p-4 rounded-xl border flex items-center justify-between gap-4 transition-all duration-300 ${isDark ? 'bg-slate-900/40 border-white/5' : 'bg-slate-50 border-slate-150'}`}>
                  <div>
                    <strong className={`text-xs block ${isDark ? 'text-white' : 'text-slate-800'}`}>Close Active Overlay</strong>
                    <span className="text-[10.5px] text-slate-500 block">Dismiss overlay widget instantly.</span>
                  </div>
                  
                  <div className={`px-3 py-1.5 rounded-lg border font-mono font-bold text-xs select-none ${isDark ? 'bg-black/40 border-indigo-900/40 text-indigo-300' : 'bg-white border-slate-200 text-indigo-650 shadow-2xs'}`}>
                    ESC
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
