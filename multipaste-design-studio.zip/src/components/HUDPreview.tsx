import React, { useState } from 'react';
import { Eye, Clock, Key, Monitor, Layers, Check, Sparkles, Terminal } from 'lucide-react';
import { ClipItem } from '../types';

interface HUDPreviewProps {
  clips: ClipItem[];
}

export default function HUDPreview({ clips }: HUDPreviewProps) {
  const [hudActive, setHudActive] = useState(true);
  const [activeClipIndex, setActiveClipIndex] = useState(0);

  const activeClip = clips[activeClipIndex] || clips[0];

  const handleNextClip = () => {
    setActiveClipIndex((prev) => (prev + 1) % clips.length);
  };

  return (
    <div id="hud-sandbox" className="p-4 sm:p-8 bg-[#090b10] min-h-screen text-slate-100 flex flex-col justify-start">
      
      {/* Title block */}
      <div className="max-w-4xl w-full mx-auto mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-900 pb-5">
        <div>
          <span className="text-xs font-mono text-purple-400 font-semibold uppercase tracking-wider">HUD Interface Simulation</span>
          <h2 className="text-2xl font-display font-bold text-white mt-1 font-sans">Floating Overlay HUD Preview</h2>
          <p className="text-xs text-slate-400 mt-1 font-sans">Simulate active on-screen widgets that pop up instantly on keystroke triggers.</p>
        </div>

        <button 
          onClick={() => setHudActive(!hudActive)}
          className="text-xs text-white font-mono self-start sm:self-center hover:bg-purple-500 bg-purple-600 px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer active:scale-95 shadow-md shadow-purple-900/20"
        >
          {hudActive ? 'Collapse HUD Display' : 'Show HUD Display'}
        </button>
      </div>

      <div className="max-w-4xl w-full mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Parameters controls */}
        <div className="md:col-span-4 bg-slate-900/60 border border-slate-800 rounded-xl p-5 shadow-xl space-y-5 text-left">
          <h3 className="font-semibold text-slate-200 text-sm border-b border-slate-850 pb-3 font-sans">Interactive HUD Parameters</h3>
          
          <div className="space-y-4">
            <div className="space-y-1.5">
              <span className="text-xs text-slate-400 font-mono block">Simulate Clip Stream Selection</span>
              <div className="space-y-1">
                {clips.slice(0, 5).map((clip, idx) => (
                  <button 
                    key={clip.id}
                    onClick={() => {
                      setActiveClipIndex(idx);
                      setHudActive(true);
                    }}
                    className={`w-full text-left p-2 rounded-lg text-xs font-mono transition-all flex items-center justify-between gap-2 cursor-pointer ${activeClipIndex === idx && hudActive ? 'bg-purple-950/40 text-purple-300 border border-purple-900/40' : 'hover:bg-slate-950 hover:text-slate-200 text-slate-400 border border-transparent'}`}
                  >
                    <span className="truncate max-w-[150px]">{clip.title || clip.type}</span>
                    <span className="text-[10px] text-slate-600">{clip.sourceApp}</span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleNextClip}
              className="w-full py-2 bg-slate-950 hover:bg-slate-900 text-xs font-mono rounded-lg border border-slate-800 text-slate-300 cursor-pointer text-center"
            >
              Cycle Clipboard Buffer items →
            </button>
          </div>

          <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl text-xs space-y-2 text-slate-400 leading-normal">
            <span className="text-amber-400 font-semibold block">📐 SwiftUI HUD Alignment</span>
            <p>
              When building native Swift HUD controllers, configure the window level to <code className="bg-slate-900 border border-slate-800 px-1 py-0.5 rounded text-slate-350">NSWindow.Level.statusBar</code> to allow it to sit stably above high-fullscreen AppKit spaces or Xcode frames.
            </p>
          </div>
        </div>

        {/* Right Side: Virtual Desktop screen staging the HUD popup */}
        <div className="md:col-span-8 flex flex-col items-center">
          <div className="text-xs text-slate-400 font-mono mb-2 self-start flex items-center gap-1.5">
            <span>💻 Screen Workspace Simulation</span>
          </div>

          {/* Virtual wallpaper window */}
          <div className="w-full h-[380px] bg-gradient-to-tr from-indigo-950 via-[#070912] to-purple-950 border border-slate-800 rounded-2xl relative flex items-center justify-center p-6 shadow-2xl overflow-hidden select-none">
            {/* Background design dots */}
            <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px] opacity-10 pointer-events-none"></div>

            {hudActive ? (
              <div className="w-full max-w-sm bg-black/60 border border-white/20 p-5 rounded-2xl shadow-[0_24px_50px_rgba(0,0,0,0.8)] backdrop-blur-xl animate-scale-up text-left z-20">
                <div className="flex items-center justify-between gap-3 border-b border-white/10 pb-3 mb-3 shrink-0">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500 animate-pulse"></span>
                    <span className="text-[11px] font-mono font-bold tracking-widest text-slate-300 uppercase">CLIP CAPTURED HUD</span>
                  </div>
                  <span className="text-[10px] text-white/40 font-mono font-medium uppercase">{activeClip.sourceApp}</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <h4 className="text-xs font-bold text-white capitalize leading-tight mb-1">
                      {activeClip.title || 'Captured item block'}
                    </h4>
                    <p className="text-[11px] text-slate-300 font-mono line-clamp-3 bg-black/40 border border-white/10 p-2.5 rounded-xl break-all leading-normal select-all">
                      {activeClip.content}
                    </p>
                  </div>

                  {activeClip.type === 'color' && activeClip.colorHex && (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded-full border border-white/20 shrink-0" style={{ backgroundColor: activeClip.colorHex }}></div>
                      <span className="text-[11px] font-mono text-purple-400">{activeClip.colorHex}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono pt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-600" /> Captured instant ago
                    </span>
                    <span className="bg-white/10 border border-white/10 text-slate-300 px-1.5 py-0.5 rounded scale-90">
                      ⌥{activeClipIndex + 1}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center bg-black/40 border border-white/10 p-4 rounded-xl max-w-xs text-xs text-slate-400">
                <span>The floating hud is currently inactive. Select any clip or click <strong>"Show HUD Display"</strong> to pop it up above this screen instantly.</span>
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
