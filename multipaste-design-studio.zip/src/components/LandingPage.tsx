import React, { useState } from 'react';
import { Download, Eclipse, Search, Sparkles, Copy, Check, MousePointer, ShieldCheck, Zap, Layers, Lock } from 'lucide-react';
import { ClipItem } from '../types';

interface LandingPageProps {
  onNavigateToSandbox: (view: string) => void;
  clips: ClipItem[];
  onAddClip: (clip: ClipItem) => void;
  isDark: boolean;
}

export default function LandingPage({ onNavigateToSandbox, clips, onAddClip, isDark }: LandingPageProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredClips = clips.filter(clip =>
    clip.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    clip.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCopyClip = (clip: ClipItem) => {
    navigator.clipboard.writeText(clip.content);
    setCopiedId(clip.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const currentYear = new Date().getFullYear();

  return (
    <div id="landing-page" className={`min-h-screen font-sans relative overflow-hidden transition-colors duration-300 selection:bg-blue-500/30`}>
      
      {/* Decorative Grid Mesh */}
      <div className={`absolute inset-0 bg-[radial-gradient(#6366f1_1px,transparent_1px)] [background-size:32px_32px] pointer-events-none transition-opacity duration-300 ${isDark ? 'opacity-[0.04]' : 'opacity-[0.02]'}`}></div>
      
      {/* Dynamic Ambient Blur Glows */}
      {isDark ? (
        <>
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-500/10 rounded-full blur-[128px] pointer-events-none"></div>
          <div className="absolute top-1/2 right-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-[96px] pointer-events-none"></div>
        </>
      ) : (
        <>
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-400/[0.04] rounded-full blur-[128px] pointer-events-none"></div>
          <div className="absolute top-1/2 right-10 w-80 h-80 bg-indigo-400/[0.03] rounded-full blur-[96px] pointer-events-none"></div>
        </>
      )}

      {/* Main Bar Navigation for Landing Page */}
      <nav className={`relative z-10 max-w-7xl mx-auto px-6 py-4 flex items-center justify-between border-b transition-colors duration-300 ${isDark ? 'border-white/10' : 'border-slate-200'}`}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 via-indigo-500 to-violet-600 flex items-center justify-center shadow-md">
            <Eclipse className="w-4 h-4 text-white rotate-12" />
          </div>
          <span className={`font-display font-bold tracking-tight text-base ${isDark ? 'text-white' : 'text-slate-900'}`}>
            Multipaste
          </span>
          <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full ${isDark ? 'bg-white/10 text-slate-350' : 'bg-slate-100 text-slate-600'}`}>
            v1.4 macOS
          </span>
        </div>

        <div className="flex items-center gap-6 text-xs font-semibold">
          <button 
            onClick={() => onNavigateToSandbox('popover')} 
            className={`transition-colors cursor-pointer ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
          >
            StatusBar Popup
          </button>
          <button 
            onClick={() => onNavigateToSandbox('dashboard')} 
            className={`transition-colors cursor-pointer ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
          >
            History Viewer
          </button>
          <button 
            onClick={() => onNavigateToSandbox('settings')} 
            className={`transition-colors cursor-pointer ${isDark ? 'text-slate-300 hover:text-white' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Secure Exclusions
          </button>
        </div>

        <div>
          <button 
            onClick={() => onNavigateToSandbox('dashboard')}
            className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-semibold transition-all text-xs shadow-xs hover:shadow-md cursor-pointer active:scale-95"
          >
            <span>Live Clipboard workspace</span>
          </button>
        </div>
      </nav>

      {/* Hero Display section */}
      <main className="relative z-10 max-w-6xl mx-auto px-6 pt-16 pb-24 text-center">
        <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono mb-6 mx-auto backdrop-blur-sm border ${isDark ? 'bg-blue-950/30 border-blue-500/20 text-blue-300' : 'bg-blue-50 border-blue-100 text-blue-600'}`}>
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>Polished macOS Clipboard Utility Application</span>
        </div>

        <h1 className={`font-display font-extrabold text-4xl sm:text-6xl tracking-tight leading-[1.15] max-w-4xl mx-auto mb-6 transition-all duration-300 ${isDark ? 'bg-gradient-to-b from-white via-slate-100 to-slate-200 bg-clip-text text-transparent' : 'text-slate-900'}`}>
          Your clipboard memory,<br />
          <span className={`${isDark ? 'text-blue-400' : 'text-blue-600'}`}>intelligent and infinite.</span>
        </h1>
        
        <p className={`max-w-2xl mx-auto text-sm sm:text-base leading-relaxed mb-8 transition-colors duration-300 ${isDark ? 'text-slate-300' : 'text-slate-600 font-medium'}`}>
          Stop losing text snippets, hex colors, screenshots, or code blocks. Multipaste runs securely in your macOS status bar, index-cataloging every copy action locally so you can recall, filter, and paste snippets instantly.
        </p>

        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mb-20">
          <button 
            onClick={() => onNavigateToSandbox('popover')}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 border rounded-xl font-semibold transition-all text-sm group cursor-pointer active:scale-98 backdrop-blur-md ${isDark ? 'bg-white/15 hover:bg-white/20 border-white/10 text-white' : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-800'}`}
          >
            <span>Launch Status Bar Simulator</span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${isDark ? 'bg-black/40 text-slate-400' : 'bg-slate-200 text-slate-600'}`}>⌥V</span>
          </button>
          
          <button 
            onClick={() => onNavigateToSandbox('dashboard')} 
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold transition-all text-sm shadow-md hover:shadow-lg active:scale-98 cursor-pointer"
          >
            <Zap className="w-4 h-4 text-blue-200" />
            <span>Interactive History Dashboard</span>
          </button>
        </div>

        {/* Feature Interactive Showcase Card simulating App clip stream using glass styling */}
        <div className={`max-w-4xl mx-auto p-6 rounded-2xl border transition-all duration-300 ${isDark ? 'bg-black/35 border-white/10 shadow-2xl backdrop-blur-3xl' : 'bg-white border-slate-200 shadow-xl shadow-slate-200/50'}`}>
          
          {/* Virtual Window Header */}
          <div className={`p-1 px-3 border-b pb-4 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4 ${isDark ? 'border-white/10' : 'border-slate-100'}`}>
            <div className="flex items-center gap-1.5 self-start">
              <span className="w-3 h-3 rounded-full bg-[#ff5f56]" />
              <span className="w-3 h-3 rounded-full bg-[#ffbd2e]" />
              <span className="w-3 h-3 rounded-full bg-[#27c93f]" />
              <span className={`text-xs font-mono ml-2 font-semibold ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Multipaste Memory Stack
              </span>
            </div>
            
            {/* Real Search Integration */}
            <div className="relative w-full sm:w-64">
              <Search className={`w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`} />
              <input 
                type="text" 
                placeholder="Fuzzy search clipboard history..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full pl-9 pr-4 py-1.5 rounded-lg text-xs font-medium focus:outline-none transition-all ${isDark ? 'bg-black/30 border border-white/10 text-slate-250 placeholder:text-slate-500 focus:border-blue-500/50' : 'bg-slate-100 border border-slate-200 text-slate-800 placeholder:text-slate-400 focus:border-blue-500 focus:bg-white'}`}
              />
            </div>
          </div>

          {/* Interactive Rows */}
          <div className="space-y-2.5 text-left max-h-[300px] overflow-y-auto pr-1">
            {filteredClips.length > 0 ? (
              filteredClips.map((clip, i) => (
                <div 
                  key={clip.id} 
                  className={`border p-3 rounded-xl flex items-center justify-between gap-4 transition-all group backdrop-blur-md ${isDark ? 'bg-white/5 border-white/5 hover:border-white/15 hover:bg-white/10 text-slate-200' : 'bg-slate-50 hover:bg-slate-100 border-slate-150/60 hover:border-slate-200 text-slate-800'}`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-7 h-7 rounded-md flex items-center justify-center font-mono text-[10px] font-bold border ${isDark ? 'bg-white/10 text-slate-200 border-white/10' : 'bg-white text-slate-700 border-slate-200 shadow-xs'}`}>
                      {clip.sourceApp.substring(0, 2).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`font-sans font-semibold text-xs leading-none ${isDark ? 'text-white' : 'text-slate-800'}`}>
                          {clip.title || clip.type.toUpperCase()}
                        </span>
                        <span className={`text-[10px] font-mono tracking-wider font-semibold ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                          {clip.sourceApp}
                        </span>
                      </div>
                      <p className={`text-[11px] font-mono mt-1 break-all truncate max-w-xs sm:max-w-xl ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                        {clip.content}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${isDark ? 'bg-white/5 text-blue-300 border-white/5' : 'bg-white text-blue-600 border-slate-200 shadow-2xs'}`}>
                      ⌥{i + 1}
                    </span>
                    <button 
                      onClick={() => handleCopyClip(clip)}
                      className={`p-1.5 rounded-lg transition-all cursor-pointer opacity-50 group-hover:opacity-100 ${isDark ? 'hover:bg-white/10 text-slate-300 hover:text-white' : 'hover:bg-slate-200 text-slate-700 hover:text-slate-900'}`}
                      aria-label="Copy clipboard item"
                    >
                      {copiedId === clip.id ? <Check className="w-3.5 h-3.5 text-emerald-550 font-bold" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className={`text-center py-12 text-xs font-mono font-semibold ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                No matching clips found in database stack.
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Feature Pillars (Simple and Gorgeous, describing how Multipaste works) */}
      <section className={`border-t relative z-10 py-16 px-6 backdrop-blur-md transition-colors duration-300 ${isDark ? 'bg-black/25 border-white/10' : 'bg-slate-100/50 border-slate-200'}`}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className={`font-display font-extrabold text-2xl ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Master your macOS flow
            </h2>
            <p className={`text-sm max-w-xl mx-auto mt-2 font-medium ${isDark ? 'text-slate-350' : 'text-slate-600'}`}>
              Multipaste sits quietly in your menu bar and unlocks powerful client-side clipboard enhancements.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className={`p-5 rounded-2xl border flex flex-col justify-between transition-all duration-300 ${isDark ? 'border-white/10 bg-white/5' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div>
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-sm mb-4 ${isDark ? 'bg-blue-500/10 border border-blue-500/20 text-blue-300' : 'bg-blue-50 border border-blue-100 text-blue-600'}`}>
                  <Zap className="w-4 h-4" />
                </div>
                <h4 className={`font-bold text-sm mb-1.5 ${isDark ? 'text-slate-100' : 'text-slate-950'}`}>Instant Key recall</h4>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-slate-350' : 'text-slate-600'}`}>
                  Trigger the beautiful overlay HUD or status menu instantly with <code className="bg-slate-250/10 px-1 py-0.5 rounded font-mono text-[10px]">⌥ ⌘ V</code>. Tap any index number like <code className="bg-slate-250/10 px-1 py-0.5 rounded font-mono text-[10px]">⌥1</code> through <code className="bg-slate-250/10 px-1 py-0.5 rounded font-mono text-[10px]">⌥9</code> to paste directly into your current editor.
                </p>
              </div>
              <span className={`text-[9px] font-mono tracking-widest font-bold mt-4 block uppercase ${isDark ? 'text-blue-400' : 'text-blue-600'}`}>
                Zero Latency Flow
              </span>
            </div>

            <div className={`p-5 rounded-2xl border flex flex-col justify-between transition-all duration-300 ${isDark ? 'border-white/10 bg-white/5' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div>
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-sm mb-4 ${isDark ? 'bg-indigo-500/10 border border-indigo-500/20 text-indigo-305' : 'bg-indigo-50 border border-indigo-100 text-indigo-600'}`}>
                  <Layers className="w-4 h-4" />
                </div>
                <h4 className={`font-bold text-sm mb-1.5 ${isDark ? 'text-slate-100' : 'text-slate-950'}`}>Smart Rich Formats</h4>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-slate-350' : 'text-slate-600'}`}>
                  Multipaste reads raw buffers of copied items and dynamically parses them into clean collections. Instantly previews Hex code swatches, formats multi-line Swift/JS code patterns, and previews captured images.
                </p>
              </div>
              <span className={`text-[9px] font-mono tracking-widest font-bold mt-4 block uppercase ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`}>
                Rich Format Support
              </span>
            </div>

            <div className={`p-5 rounded-2xl border flex flex-col justify-between transition-all duration-300 ${isDark ? 'border-white/10 bg-white/5' : 'bg-white border-slate-200 shadow-sm'}`}>
              <div>
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-sm mb-4 ${isDark ? 'bg-rose-500/10 border border-rose-500/20 text-rose-300' : 'bg-rose-50 border border-rose-100 text-rose-600'}`}>
                  <Lock className="w-4 h-4" />
                </div>
                <h4 className={`font-bold text-sm mb-1.5 ${isDark ? 'text-slate-100' : 'text-slate-950'}`}>Local-First Security</h4>
                <p className={`text-xs leading-relaxed ${isDark ? 'text-slate-350' : 'text-slate-600'}`}>
                  Your clipboard contains sensitive information. Multipaste runs totally local on your Mac, and lets you build an active exclusion list. Password managers like Keychain or Bitwarden are automatically excluded from storage.
                </p>
              </div>
              <span className={`text-[9px] font-mono tracking-widest font-bold mt-4 block uppercase ${isDark ? 'text-rose-400' : 'text-rose-600'}`}>
                100% Secure Storage
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Simple elegant Display Footer */}
      <footer className={`py-8 text-center text-xs font-mono relative z-10 transition-colors duration-300 ${isDark ? 'bg-black/25 text-slate-500 border-t border-white/5' : 'bg-slate-100/30 text-slate-500 border-t border-slate-200'}`}>
        <p>© {currentYear} Multipaste. Built securely for macOS. Under MIT license.</p>
      </footer>
    </div>
  );
}
