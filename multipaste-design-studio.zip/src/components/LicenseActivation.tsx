import React, { useState } from 'react';
import { Award, CheckCircle, Key, Lock, ArrowRight, Sparkles } from 'lucide-react';

interface LicenseActivationProps {
  onSuccessActivate: () => void;
  isDark: boolean;
}

export default function LicenseActivation({ onSuccessActivate, isDark }: LicenseActivationProps) {
  const [licenseKey, setLicenseKey] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorText, setErrorText] = useState('');

  const handleValidate = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText('');

    if (licenseKey.trim().length < 8) {
      setErrorText('Please specify a valid 16-character license key (e.g. MPAS-XXXX-XXXX-XXXX)');
      return;
    }

    setIsValidating(true);
    
    // Simulate activation validation
    setTimeout(() => {
      setIsValidating(false);
      setIsSuccess(true);
      setTimeout(() => {
        onSuccessActivate();
      }, 1500);
    }, 1200);
  };

  return (
    <div id="license-portal-stage" className="p-4 sm:p-6 min-h-screen flex flex-col justify-start transition-colors duration-300 font-sans">
      
      {/* Page Title */}
      <div className={`max-w-2xl w-full mx-auto mb-6 text-center sm:text-left border-b pb-4 transition-all duration-300 ${isDark ? 'border-white/10' : 'border-slate-200'}`}>
        <span className={`text-[10px] font-mono font-bold uppercase tracking-wider ${isDark ? 'text-indigo-400' : 'text-indigo-650'}`}>
          Premium Upgrades
        </span>
        <h2 className={`text-base font-bold mt-0.5 ${isDark ? 'text-white' : 'text-slate-900'}`}>
          Activate Multipaste Pro License
        </h2>
        <p className={`text-[11px] leading-tight mt-0.5 ${isDark ? 'text-slate-405' : 'text-slate-550'}`}>
          Unlock continuous clipboard backup, universal cross-device synchronization, and extended filter capabilities.
        </p>
      </div>

      <div className={`max-w-xl w-full mx-auto border p-6 md:p-8 rounded-2xl shadow-lg relative overflow-hidden text-left transition-all duration-300 ${isDark ? 'bg-slate-900/40 border-indigo-500/25' : 'bg-white border-slate-200 shadow-slate-200/50'}`}>
        {/* Decorative ambient gradient inside card */}
        <div className={`absolute -top-24 -right-12 w-48 h-48 rounded-full blur-3xl pointer-events-none ${isDark ? 'bg-purple-600/5' : 'bg-blue-500/[0.04]'}`}></div>

        {isSuccess ? (
          <div className="text-center py-10 space-y-4 animate-fade-in">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto border shadow-sm ${isDark ? 'bg-emerald-950/40 border-emerald-500/35 text-emerald-400' : 'bg-emerald-50 border-emerald-200 text-emerald-600'}`}>
              <CheckCircle className="w-8 h-8 font-bold" />
            </div>
            <div>
              <h3 className={`font-bold text-base ${isDark ? 'text-slate-100' : 'text-slate-900'}`}>
                Multipaste Pro Active!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Your premium license has been recognized. All boundaries are now unlocked.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className={`flex items-start gap-4 pb-4 border-b ${isDark ? 'border-white/5' : 'border-slate-150'}`}>
              <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center shadow-xs shrink-0">
                <Award className="w-5.5 h-5.5 text-white" />
              </div>
              <div>
                <h3 className={`font-bold text-sm ${isDark ? 'text-slate-200' : 'text-slate-900'}`}>
                  Unlock Pro Continuous Sync
                </h3>
                <p className="text-xs text-slate-450 mt-0.5 leading-snug">
                  Transform your workflow with a beautiful, unified clipboard space across all of your computing devices.
                </p>
              </div>
            </div>

            {/* Feature lists */}
            <div className="space-y-3">
              {[
                { title: 'Unlimited Clipboard Backlog', desc: 'Maintain thousands of clippings in your secure local index database.' },
                { title: 'iCloud Universal Sync', desc: 'Securely sync copy and paste buffers across macOS, iPad, and iOS on the fly.' },
                { title: 'Advanced Regex Search index', desc: 'Apply powerful regular-expression filtering to trace old code chunks in seconds.' },
                { title: 'Infinite Blocklist Exclusions', desc: 'Specify as many secure applications to filter out as you need with no caps.' }
              ].map((feat, i) => (
                <div key={i} className="flex gap-3 text-xs leading-normal">
                  <div className={`font-bold shrink-0 mt-0.5 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`}>✦</div>
                  <div>
                    <strong className={`block ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>{feat.title}</strong>
                    <span className="text-slate-500 font-medium">{feat.desc}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Form */}
            <form onSubmit={handleValidate} className={`space-y-3.5 border-t pt-5 ${isDark ? 'border-white/5' : 'border-slate-150'}`}>
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono font-bold text-slate-500 block flex justify-between select-none">
                  <span>ENTER 16-CHAR LICENSE KEY</span>
                  <span>MPAS-XXXX-XXXX-XXXX</span>
                </label>
                
                <div className="relative">
                  <Key className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input 
                    type="text" 
                    placeholder="e.g. MPAS-7389-AXCE-9021"
                    value={licenseKey}
                    onChange={(e) => setLicenseKey(e.target.value.toUpperCase())}
                    disabled={isValidating}
                    className={`w-full text-xs font-semibold px-3 pl-9 py-2 rounded-xl focus:outline-none focus:border-blue-500 font-mono text-slate-200 uppercase placeholder:text-slate-600 disabled:opacity-50 ${isDark ? 'bg-black/35 border-white/5 text-white' : 'bg-slate-100 border-slate-200 text-slate-850'}`}
                  />
                </div>

                {errorText && (
                  <p className="text-[10px] text-red-500 font-mono mt-1 leading-normal">
                    ⚠️ {errorText}
                  </p>
                )}
              </div>

              <div className="flex gap-2.5 pt-1">
                <button 
                  type="submit"
                  disabled={isValidating}
                  className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800/50 font-bold text-xs rounded-xl text-white transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:cursor-not-allowed active:scale-98 shadow-xs"
                >
                  {isValidating ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                      <span>Validating cryptographic key...</span>
                    </>
                  ) : (
                    <>
                      <span>Activate Premium Pro Features</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className={`mt-5 p-3.5 border-t text-[11px] font-sans flex items-start gap-2.5 ${isDark ? 'bg-black/25 border-white/5 text-slate-500' : 'bg-slate-50 border-slate-150 text-slate-550'}`}>
          <Lock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <p>
            <strong>Interactive upgrade simulator:</strong> Type any mock text matching 8 or more characters (e.g. <code className="bg-slate-250/15 border border-slate-200 px-1 py-0.5 rounded font-mono text-[10px]">PREMIUM-PRO-KEY</code>) to simulate local activation and unlock continuous memory triggers.
          </p>
        </div>
      </div>
    </div>
  );
}
