import React, { useState } from 'react';
import { Search, Grid, List, Tag, Eye, Layers, Copy, Check, Info, FileText, Code2, Link, Palette, ImageIcon, Calendar, Clock, Monitor, AppWindow } from 'lucide-react';
import { ClipItem } from '../types';

interface ActiveDashboardProps {
  clips: ClipItem[];
  onAddClip: (clip: ClipItem) => void;
  isDark: boolean;
}

export default function ActiveDashboard({
  clips,
  onAddClip,
  isDark
}: ActiveDashboardProps) {
  const [selectedId, setSelectedId] = useState<string>('1');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'code' | 'color' | 'link' | 'text' | 'image'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewStyle, setViewStyle] = useState<'list' | 'grid'>('list');
  const [copiedText, setCopiedText] = useState(false);

  // Fallback to first clip if selectedId is not found
  const selectedClip = clips.find(c => c.id === selectedId) || clips[0] || null;

  const filteredClips = clips.filter(clip => {
    const matchesCategory = categoryFilter === 'all' || clip.type === categoryFilter;
    const matchesSearch = clip.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          clip.sourceApp.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (clip.title && clip.title.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const getCategoryIcon = (type: string) => {
    switch (type) {
      case 'code': return <Code2 className="w-3.5 h-3.5" />;
      case 'color': return <Palette className="w-3.5 h-3.5" />;
      case 'link': return <Link className="w-3.5 h-3.5" />;
      case 'image': return <ImageIcon className="w-3.5 h-3.5" />;
      default: return <FileText className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div id="active-dashboard-canvas" className="p-4 sm:p-6 min-h-screen flex flex-col justify-start transition-colors duration-300 font-sans">
      
      {/* Title section */}
      <div className={`max-w-7xl w-full mx-auto mb-6 p-4 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-4 transition-all duration-300 ${isDark ? 'bg-black/30 border-white/10 text-white' : 'bg-white border-slate-250/75 text-slate-850 shadow-xs'}`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-650 flex items-center justify-center font-bold text-white text-md">
            M
          </div>
          <div>
            <h3 className="text-sm font-bold">Interactive Clipboard Viewer</h3>
            <p className={`text-[11px] font-medium ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              Browse and search everything captured in your active memory buffer
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold">
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold ${isDark ? 'bg-black/40 text-blue-300' : 'bg-blue-50 text-blue-600'}`}>
            {clips.length} Clips Cache
          </span>
          <span className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold ${isDark ? 'bg-black/40 text-emerald-300' : 'bg-emerald-50 text-emerald-600'}`}>
            Local SQLite Active
          </span>
        </div>
      </div>

      {/* Main Grid Columns Workspace */}
      <div className="max-w-7xl w-full mx-auto grid grid-cols-1 md:grid-cols-12 gap-6 items-start flex-1 mb-10">
        
        {/* Left Column: Filter panel */}
        <div className={`md:col-span-3 rounded-2xl border p-4 shadow-md transition-all duration-300 ${isDark ? 'bg-slate-900/30 border-white/10 text-slate-200' : 'bg-white border-slate-200 text-slate-700 shadow-slate-200/40'}`}>
          <h4 className={`text-[10px] font-bold tracking-wider uppercase mb-3 font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Filter Collections
          </h4>
          
          <div className="space-y-1 font-sans">
            {[
              { id: 'all', label: 'All Clippings', count: clips.length },
              { id: 'code', label: 'Code Snippets', count: clips.filter(c => c.type === 'code').length },
              { id: 'color', label: 'Color Swatches', count: clips.filter(c => c.type === 'color').length },
              { id: 'link', label: 'Captured Links', count: clips.filter(c => c.type === 'link').length },
              { id: 'text', label: 'Plain Text', count: clips.filter(c => c.type === 'text').length },
              { id: 'image', label: 'Screenshots', count: clips.filter(c => c.type === 'image').length },
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id as any)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-semibold tracking-wide transition-all text-left cursor-pointer ${categoryFilter === cat.id ? 'bg-blue-600 text-white shadow-xs' : (isDark ? 'hover:bg-white/5 text-slate-300' : 'hover:bg-slate-100 text-slate-600')}`}
              >
                <div className="flex items-center gap-2">
                  {getCategoryIcon(cat.id)}
                  <span>{cat.label}</span>
                </div>
                <span className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${categoryFilter === cat.id ? 'bg-blue-700 text-blue-105' : (isDark ? 'bg-black/25 text-slate-400' : 'bg-slate-100 text-slate-500')}`}>
                  {cat.count}
                </span>
              </button>
            ))}
          </div>

          <div className={`mt-6 pt-4 border-t text-[11px] font-sans leading-relaxed transition-all duration-300 ${isDark ? 'border-white/10 text-slate-405' : 'border-slate-150 text-slate-500'}`}>
            <span className={`font-bold flex items-center gap-1 mb-1 ${isDark ? 'text-blue-300' : 'text-blue-600'}`}>
              <Monitor className="w-3.5 h-3.5" />
              <span>Smart Buffering</span>
            </span>
            <p className="leading-normal">
              Multipaste identifies bundle applications origin and keeps SSH keys, terminal tokens, and keychain clips completely filtered dynamically for security.
            </p>
          </div>
        </div>

        {/* Middle Column: Items list */}
        <div className={`md:col-span-5 rounded-2xl border p-4 shadow-md min-h-[450px] flex flex-col transition-all duration-300 ${isDark ? 'bg-black/25 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200/40'}`}>
          
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="relative flex-1">
              <Search className={`w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`} />
              <input 
                type="text" 
                placeholder="Search history content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className={`w-full pl-9 pr-4 py-1.5 text-xs font-medium rounded-xl focus:outline-none focus:border-blue-500 focus:bg-white/10 ${isDark ? 'bg-black/30 border-white/10 text-white placeholder:text-slate-500' : 'bg-slate-100 border-slate-200 text-slate-800 placeholder:text-slate-400'}`}
              />
            </div>

            {/* View style toggle */}
            <div className={`flex items-center gap-1 p-1 rounded-lg border ${isDark ? 'bg-black/30 border-white/10' : 'bg-slate-100 border-slate-200'}`}>
              <button 
                onClick={() => setViewStyle('list')}
                className={`p-1 rounded cursor-pointer transition-all ${viewStyle === 'list' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-600'}`}
                aria-label="List view"
              >
                <List className="w-3.5 h-3.5" />
              </button>
              <button 
                onClick={() => setViewStyle('grid')}
                className={`p-1 rounded cursor-pointer transition-all ${viewStyle === 'grid' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-600'}`}
                aria-label="Grid view"
              >
                <Grid className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 max-h-[450px] pr-1">
            {filteredClips.length > 0 ? (
              <div className={viewStyle === 'grid' ? 'grid grid-cols-2 gap-2' : 'space-y-2'}>
                {filteredClips.map((clip, idx) => {
                  const isSelected = clip.id === selectedId;
                  
                  return (
                    <div 
                      key={clip.id}
                      onClick={() => setSelectedId(clip.id)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer text-left relative group ${
                        isSelected 
                          ? 'bg-blue-500/10 border-blue-500 text-white shadow-xs' 
                          : (isDark 
                              ? 'bg-white/5 border-transparent hover:border-white/10 hover:bg-white/10 text-slate-250' 
                              : 'bg-slate-50 border-slate-150/60 hover:border-slate-300 hover:bg-slate-100 text-slate-800')
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${isDark ? 'bg-black/30 text-slate-400' : 'bg-white text-slate-600 border border-slate-200 shadow-2xs'}`}>
                          {clip.sourceApp}
                        </span>
                        <span className={`text-[9px] font-mono font-bold ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                          ⌥{idx + 1}
                        </span>
                      </div>

                      <h5 className={`font-sans font-semibold text-xs mt-2 line-clamp-1 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                        {clip.title || clip.content.substring(0, 30)}
                      </h5>

                      <p className={`text-[11px] font-mono mt-1 line-clamp-2 leading-relaxed ${isDark ? 'text-slate-450' : 'text-slate-550'}`}>
                        {clip.content}
                      </p>

                      {clip.type === 'color' && clip.colorHex && (
                        <div className="flex items-center gap-1.5 mt-2">
                          <div className="w-3.5 h-3.5 rounded-full border border-black/20 shrink-0" style={{ backgroundColor: clip.colorHex }}></div>
                          <span className="text-[10px] font-mono font-bold text-indigo-400">{clip.colorHex}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 text-xs text-slate-400 font-mono">
                No matching clips in stack.
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Inspector details */}
        <div className={`md:col-span-4 rounded-2xl border p-5 shadow-md flex flex-col justify-between transition-all duration-300 min-h-[450px] ${isDark ? 'bg-black/25 border-white/10 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-slate-200/40'}`}>
          {selectedClip ? (
            <div className="space-y-6 text-left flex-1 flex flex-col justify-between">
              
              <div className="space-y-4">
                <div className={`border-b pb-4 ${isDark ? 'border-white/10' : 'border-slate-150'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[9.5px] font-bold px-2 py-0.5 rounded uppercase font-mono tracking-wider ${isDark ? 'text-indigo-300 bg-indigo-950/40 border border-indigo-900/30' : 'text-indigo-650 bg-indigo-50 border border-indigo-100'}`}>
                      {selectedClip.type}
                    </span>
                    <span className={`text-[10px] font-mono font-medium ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                      {selectedClip.byteSize}
                    </span>
                  </div>
                  <h4 className={`font-sans text-sm font-bold tracking-tight leading-snug ${isDark ? 'text-white' : 'text-slate-900'}`}>
                    {selectedClip.title || 'Untitled Clipboard Clip'}
                  </h4>
                </div>

                {/* Content preview blocks */}
                <div className="space-y-3">
                  
                  {selectedClip.type === 'code' && (
                    <div className="bg-slate-950/95 text-[10px] font-mono p-3 rounded-lg border border-slate-850 text-emerald-400 overflow-x-auto whitespace-pre leading-relaxed relative max-h-[160px]">
                      <span className="absolute right-2 top-2 text-[8px] text-slate-500 tracking-wider">
                        {selectedClip.codeLanguage || 'code'}
                      </span>
                      {selectedClip.content.split('\n').map((line, lidx) => (
                        <div key={lidx} className="flex gap-2.5">
                          <span className="text-slate-700 text-right w-4 select-none">{lidx + 1}</span>
                          <span>{line}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedClip.type === 'color' && selectedClip.colorHex && (
                    <div className="space-y-2">
                      <div className="w-full h-20 rounded-xl border border-black/15 shadow-inner" style={{ backgroundColor: selectedClip.colorHex }}></div>
                      <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                        <div className={`p-2 rounded-xl border ${isDark ? 'bg-slate-950 border-slate-850' : 'bg-slate-50 border-slate-150'}`}>
                          <span className="block text-[8.5px] text-slate-500">HEX STRING</span>
                          <span className="font-bold text-slate-350">{selectedClip.colorHex}</span>
                        </div>
                        <div className={`p-2 rounded-xl border ${isDark ? 'bg-slate-950 border-slate-850' : 'bg-slate-50 border-slate-150'}`}>
                          <span className="block text-[8.5px] text-slate-500 font-semibold">SOURCE APP</span>
                          <span className="font-bold text-slate-350">{selectedClip.sourceApp}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedClip.type === 'link' && (
                    <div className={`border rounded-xl p-3 text-xs leading-normal font-mono ${isDark ? 'bg-slate-950/70 border-slate-850' : 'bg-slate-50 border-slate-150'}`}>
                      <span className="text-[9px] text-slate-500 block mb-1 font-semibold uppercase">Captured Web URL</span>
                      <a href={selectedClip.content} target="_blank" rel="noreferrer" className="text-blue-500 hover:underline break-all block font-bold">
                        {selectedClip.content}
                      </a>
                    </div>
                  )}

                  {selectedClip.type === 'image' && selectedClip.previewUrl && (
                    <div className="space-y-2">
                      <div className="w-full max-h-[120px] overflow-hidden rounded-xl border border-slate-205">
                        <img src={selectedClip.previewUrl} alt="Screenshot clip mockup" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                      <span className="text-[9.5px] text-slate-500 font-mono block text-center">Figma Captured Canvas Capture (PNG)</span>
                    </div>
                  )}

                  {selectedClip.type === 'text' && (
                    <div className={`p-3 rounded-xl border text-xs leading-relaxed max-h-[140px] overflow-y-auto ${isDark ? 'bg-slate-950/50 border-slate-850 text-slate-300' : 'bg-slate-50 border-slate-150 text-slate-600 font-medium'}`}>
                      {selectedClip.content}
                    </div>
                  )}

                  {/* Tech specs */}
                  <div className={`p-3 rounded-xl border space-y-2 font-mono text-[9px] ${isDark ? 'bg-slate-950/40 border-slate-850 text-slate-400' : 'bg-slate-50 border-slate-150 text-slate-500 font-semibold'}`}>
                    <div className="flex justify-between items-center">
                      <span className="flex items-center gap-1"><AppWindow className="w-3 h-3 text-slate-450" /> Bundle:</span>
                      <span className="text-slate-350 truncate max-w-[150px]">{selectedClip.sourceAppBundle}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-slate-450" /> Recorded:</span>
                      <span className="text-slate-350">May 24, 2026</span>
                    </div>
                  </div>

                </div>
              </div>

              {/* Action trigger copy */}
              <div className="pt-4 mt-4">
                <button
                  onClick={() => handleCopyText(selectedClip.content)}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold cursor-pointer transition-all active:scale-95 shadow-xs"
                >
                  {copiedText ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Copied Successfully</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Paste clipboard</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          ) : (
            <div className="text-center py-20 text-slate-400 font-mono text-xs flex-1 flex items-center justify-center">
              Select clip item from history list.
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
