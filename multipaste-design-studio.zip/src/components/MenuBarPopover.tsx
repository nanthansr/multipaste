import React, { useState } from 'react';
import { Search, Compass, ChevronDown, Check, RotateCcw, Shield, Trash2, Battery, Wifi, Clock, Copy, AlignLeft } from 'lucide-react';
import { ClipItem, AppPreferences } from '../types';

interface MenuBarPopoverProps {
  clips: ClipItem[];
  onAddClip: (clip: ClipItem) => void;
  onClearClips: () => void;
  preferences: AppPreferences;
  onUpdatePreferences: (pref: Partial<AppPreferences>) => void;
  isDark: boolean;
}

export default function MenuBarPopover({
  clips,
  onAddClip,
  onClearClips,
  preferences,
  onUpdatePreferences,
  isDark
}: MenuBarPopoverProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [selectedId, setSelectedId] = useState<string>('1');
  const [localSearch, setLocalSearch] = useState('');
  const [windowWidth, setWindowWidth] = useState(360);
  const [windowHeight, setWindowHeight] = useState(480);
  const [cornerRadius, setCornerRadius] = useState(12);

  const selectedClip = clips.find(c => c.id === selectedId) || clips[0] || null;

  const filteredClips = clips.filter(clip =>
    clip.content.toLowerCase().includes(localSearch.toLowerCase()) ||
    clip.sourceApp.toLowerCase().includes(localSearch.toLowerCase()) ||
    (clip.title && clip.title.toLowerCase().includes(localSearch.toLowerCase()))
  );

  const handleSelectClip = (id: string) => {
    setSelectedId(id);
  };

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content);
  };

  // Simulated Time & Date formatters
  const currentTime = '10:42 AM';
  const currentDate = 'May 24';

  return (
    <div id="menubar-popover-sandbox" className="p-4 sm:p-6 min-h-screen flex flex-col justify-start transition-colors duration-300 font-sans">
      
      {/* Title Header */}
      <div className={`max-w-6xl w-full mx-auto mb-6 p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all duration-300 ${isDark ? 'bg-black/35 border-white/10 text-white' : 'bg-white border-slate-205 text-slate-850 shadow-xs'}`}>
        <div>
          <span className={`text-[10px] font-mono font-bold uppercase ${isDark ? 'text-blue-400' : 'text-blue-600'}`}>
            macOS Status Bar App Simulation
          </span>
          <h2 className="text-base font-bold mt-0.5">Status Popover Controller</h2>
          <p className={`text-[11px] leading-tight mt-0.5 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
            Configure how Multipaste displays directly when you tap the menu bar status icon.
          </p>
        </div>
        <div className="flex items-center gap-2 text-[11px] font-mono">
          <span className={`font-bold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>● Standalone Helper Engine Active</span>
        </div>
      </div>

      <div className="max-w-6xl w-full mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-6">
        
        {/* Geometry & Controls Sidebar */}
        <div className={`lg:col-span-4 rounded-2xl border p-5 shadow-md flex flex-col gap-5 transition-all duration-300 ${isDark ? 'bg-[#0f121d] border-white/10 text-slate-250' : 'bg-white border-slate-202 text-slate-750 shadow-slate-200/40'}`}>
          <h3 className="font-bold text-xs uppercase tracking-wider border-b border-white/5 pb-2">
            Popover Geometry
          </h3>
          
          {/* Width slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="font-medium text-slate-400">Width limit (pixels)</span>
              <span className="font-bold text-blue-505">{windowWidth}px</span>
            </div>
            <input 
              type="range" 
              min={320} 
              max={430} 
              value={windowWidth} 
              onChange={(e) => setWindowWidth(Number(e.target.value))}
              className="w-full h-1 bg-slate-200/60 rounded-lg appearance-none cursor-pointer accent-blue-650"
            />
          </div>

          {/* Height slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="font-medium text-slate-400">Height limit (pixels)</span>
              <span className="font-bold text-blue-505">{windowHeight}px</span>
            </div>
            <input 
              type="range" 
              min={400} 
              max={550} 
              value={windowHeight} 
              onChange={(e) => setWindowHeight(Number(e.target.value))}
              className="w-full h-1 bg-slate-200/60 rounded-lg appearance-none cursor-pointer accent-blue-650"
            />
          </div>

          {/* Corner radius slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="font-medium text-slate-400">Corner radius (pixels)</span>
              <span className="font-bold text-blue-505">{cornerRadius}px</span>
            </div>
            <input 
              type="range" 
              min={4} 
              max={20} 
              value={cornerRadius} 
              onChange={(e) => setCornerRadius(Number(e.target.value))}
              className="w-full h-1 bg-slate-200/60 rounded-lg appearance-none cursor-pointer accent-blue-650"
            />
          </div>

          {/* Settings switch */}
          <div className={`border-t pt-4 space-y-2 ${isDark ? 'border-white/10' : 'border-slate-150'}`}>
            <span className="text-xs font-bold text-slate-400 block uppercase">Functional parameters</span>
            
            {/* FIFO toggle */}
            <label className={`flex items-center justify-between p-2.5 rounded-lg border cursor-pointer transition-all ${isDark ? 'bg-black/15 border-white/5 hover:bg-black/35' : 'bg-slate-50 border-slate-150 hover:bg-slate-100'}`}>
              <div className="flex flex-col text-left">
                <span className="text-xs font-semibold">FIFO Mode</span>
                <span className="text-[10px] text-slate-500 font-medium">Auto-paste copied sequence</span>
              </div>
              <input 
                type="checkbox" 
                checked={preferences.collectInFIFO} 
                onChange={(e) => onUpdatePreferences({ collectInFIFO: e.target.checked })}
                className="rounded text-blue-600 focus:ring-blue-550"
              />
            </label>

            {/* Clear button */}
            <button 
              onClick={onClearClips}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-red-650/10 hover:bg-red-650/20 text-red-500 border border-red-500/20 rounded-lg text-xs font-bold transition-all cursor-pointer active:scale-95"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History ({clips.length} chips)</span>
            </button>
          </div>
        </div>

        {/* Live Status Bar Device Frame Stage */}
        <div className="lg:col-span-8 flex flex-col items-center">
          <div className="text-xs font-mono text-slate-500 mb-2.5 self-start flex gap-2 items-center">
            <span>🔴 macOS Desktop Frame simulation</span>
            <span>|</span>
            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="text-blue-500 font-semibold hover:underline cursor-pointer"
            >
              {isOpen ? 'Close Popover View' : 'Open Popover View'}
            </button>
          </div>

          {/* Device bar screen container */}
          <div className={`w-full border rounded-2xl overflow-hidden shadow-xl min-h-[500px] relative transition-all duration-300 ${isDark ? 'bg-indigo-950/20 border-white/10' : 'bg-sky-50 border-slate-200'}`}>
            
            {/* Simulated Desktop Wallpaper Backplate */}
            <div className={`absolute inset-0 z-0 pointer-events-none transition-all duration-300 ${isDark ? 'bg-gradient-to-tr from-indigo-950/50 via-slate-905 to-purple-950/40 opacity-100' : 'bg-gradient-to-tr from-sky-200/40 via-white to-blue-200/50 opacity-100'}`}></div>

            {/* Mac Menu Bar Row */}
            <div className={`w-full border-b px-4 py-1.5 flex items-center justify-between text-xs select-none font-sans relative z-30 transition-all duration-300 ${isDark ? 'bg-black/65 border-black/40 text-slate-300' : 'bg-white/90 border-slate-200 text-slate-700 shadow-xs'}`}>
              <div className="flex items-center gap-4 font-bold text-slate-500">
                <span className={`font-black text-sm select-none ${isDark ? 'text-white' : 'text-slate-800'}`}></span>
                <span>File</span>
                <span>Edit</span>
                <span>View</span>
                <span>Window</span>
              </div>

              {/* Menu Statusbar helpers */}
              <div className="flex items-center gap-3.5">
                <button 
                  onClick={() => setIsOpen(!isOpen)}
                  className={`flex items-center gap-1.5 px-2 py-0.75 rounded-md transition-all cursor-pointer font-bold ${isOpen ? 'bg-blue-600 text-white shadow-xs' : (isDark ? 'hover:bg-white/10 text-slate-300' : 'hover:bg-slate-100 text-slate-600')}`}
                >
                  <Compass className="w-3.5 h-3.5 text-blue-320" />
                  <span className="text-[10.5px]">⇧⌥V</span>
                </button>
                <div className="flex items-center gap-2.5 font-semibold text-slate-500">
                  <Wifi className="w-3.5 h-3.5" />
                  <Battery className="w-3.5 h-3.5" />
                  <span className="text-[11px]">{currentTime}</span>
                </div>
              </div>
            </div>

            {/* Simulated Workspace area showing Popover */}
            <div className="absolute inset-0 top-[31px] flex justify-end items-start pt-2 pr-4 z-20 pb-4 overflow-y-auto">
              {isOpen ? (
                <div 
                  style={{ 
                    width: `${windowWidth}px`, 
                    height: `${windowHeight}px`,
                    borderRadius: `${cornerRadius}px`
                  }}
                  className={`border shadow-2xl overflow-hidden flex flex-col transition-all duration-300 ${isDark ? 'bg-slate-950/90 border-white/10 text-white shadow-black/80 backdrop-blur-2xl' : 'bg-white/95 border-slate-200 text-slate-800 shadow-slate-300/40 backdrop-blur-xl'}`}
                >
                  
                  {/* Popover search bar header */}
                  <div className={`p-3 border-b flex items-center justify-between gap-3 shrink-0 ${isDark ? 'border-white/10 bg-black/20' : 'border-slate-150 bg-slate-50'}`}>
                    <div className="relative flex-1">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input 
                        type="text" 
                        placeholder="Type to search clipboard history..."
                        value={localSearch}
                        onChange={(e) => setLocalSearch(e.target.value)}
                        className={`w-full pl-8 pr-3 py-1 text-xs rounded-lg focus:outline-none focus:border-blue-550 ${isDark ? 'bg-black/35 border-white/5 text-white placeholder:text-slate-500' : 'bg-white border-slate-200 text-slate-800 placeholder:text-slate-400'}`}
                      />
                    </div>
                  </div>

                  {/* List stream of items */}
                  <div className="flex-1 overflow-y-auto p-2 space-y-1.5 max-h-[300px]">
                    {filteredClips.length > 0 ? (
                      filteredClips.map((clip) => {
                        const isSelected = clip.id === selectedId;
                        return (
                          <div 
                            key={clip.id}
                            onClick={() => handleSelectClip(clip.id)}
                            className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer relative group ${
                              isSelected 
                                ? 'bg-blue-600 text-white border-blue-500 shadow-2xs' 
                                : (isDark 
                                    ? 'bg-white/5 border-transparent hover:bg-white/10 hover:border-white/10 text-slate-200' 
                                    : 'bg-slate-50 border-transparent hover:border-slate-200 hover:bg-slate-100 text-slate-800')
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className={`text-[8.5px] font-mono leading-none tracking-tight font-bold px-1 rounded uppercase ${isSelected ? 'bg-blue-700 text-white' : (isDark ? 'bg-black/30 text-slate-400' : 'bg-white text-slate-500 border border-slate-150 shadow-2xs')}`}>
                                  {clip.sourceApp}
                                </span>
                              </div>
                              <span className={`text-[8.5px] font-mono font-medium ${isSelected ? 'text-white' : 'text-slate-500'}`}>
                                {clip.byteSize}
                              </span>
                            </div>

                            <p className="text-[11px] font-mono mt-1 break-all line-clamp-2 leading-relaxed">
                              {clip.content}
                            </p>
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-center py-10 text-[11px] font-mono text-slate-500">
                        No clips match query.
                      </div>
                    )}
                  </div>

                  {/* Detailed Inspect / Fast Action Block */}
                  {selectedClip && (
                    <div className={`border-t p-3 shrink-0 text-left transition-colors duration-300 ${isDark ? 'bg-black/35 border-white/10' : 'bg-slate-50 border-slate-150'}`}>
                      <div className="flex justify-between items-center mb-1">
                        <span className={`text-[9.5px] font-mono font-bold uppercase ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`}>
                          Selected block (Alt-Enter to copy)
                        </span>
                        <span className="text-[9px] text-slate-500 font-mono font-bold">
                          {selectedClip.sourceAppBundle}
                        </span>
                      </div>
                      <p className={`text-[10.5px] font-mono line-clamp-2 mb-2 leading-tight ${isDark ? 'text-slate-300' : 'text-slate-600 font-medium'}`}>
                        {selectedClip.content}
                      </p>
                      
                      <button 
                        onClick={() => handleCopy(selectedClip.content)}
                        className="w-full flex items-center justify-center gap-1.5 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg text-[10.5px] transition-all cursor-pointer active:scale-95"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Instant Paste Clipboard</span>
                      </button>
                    </div>
                  )}

                </div>
              ) : (
                <div className={`text-center py-6 px-4 rounded-xl border max-w-xs text-xs font-medium transition-all duration-300 ${isDark ? 'bg-black/40 border-white/10 text-slate-400' : 'bg-white border-slate-200 text-slate-500 shadow-md'}`}>
                  <span>The status menu popover is currently collapsed. Click the <strong>"⌥V Compass icon"</strong> on the status bar or the link above to expand.</span>
                </div>
              )}

            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
